package qlvpp.gui;
import javax.swing.*;
public class TrangChuGUI extends JPanel {
    public TrangChuGUI() {
        add(new JLabel("Trang Chủ"));
    }
}